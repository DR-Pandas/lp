const http = require('http');
const fs = require('fs');

const server = http.createServer((req, res) => {

    fs.readFile('index.html', (err, data) => {

        if(err)
        {
            res.writeHead(404, {'Content-Type':'text/html'});
            res.write("File Not Found");
            return res.end();
        }

        res.writeHead(200, {'Content-Type':'text/html'});
        res.write(data);
        res.end();
    });

});

server.listen(3000, () => {
    console.log("Server running at http://localhost:3000");
});